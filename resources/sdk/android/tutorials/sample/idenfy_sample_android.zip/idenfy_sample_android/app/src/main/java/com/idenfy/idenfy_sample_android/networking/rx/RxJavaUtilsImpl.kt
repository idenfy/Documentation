package com.idenfy.idenfy_sample_android.networking.rx

import io.reactivex.Scheduler
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class RxJavaUtilsImpl : RxJavaUtils {
    override fun getSchedulersIO(): Scheduler {
        return Schedulers.io()
    }

    override fun getAndroidSchedulersMainThread(): Scheduler {
        return AndroidSchedulers.mainThread()
    }

}