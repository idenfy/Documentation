package com.idenfy.idenfy_sample_android.di

import com.idenfy.idenfy_sample_android.networking.APIService
import com.idenfy.idenfy_sample_android.networking.RetrofitFactory
import com.idenfy.idenfy_sample_android.networking.rx.RxJavaUtils
import com.idenfy.idenfy_sample_android.networking.rx.RxJavaUtilsImpl

class ServiceLocator {

    val apiService: APIService by lazy {
        RetrofitFactory.makeRetrofitService()
    }
    val rxJavaUtils: RxJavaUtils by lazy {
        RxJavaUtilsImpl()
    }
}