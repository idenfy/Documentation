package com.idenfy.idenfy_sample_android.networking

import com.idenfy.idenfy_sample_android.data.models.AuthToken
import com.idenfy.idenfy_sample_android.data.models.AuthTokenBody
import io.reactivex.Single
import retrofit2.http.Body
import retrofit2.http.Headers
import retrofit2.http.POST

interface APIService {
    @Headers("Content-Type: application/json")
    @POST("api/v2/token")
    fun getAppToken(
        @Body authTokenBody: AuthTokenBody
    ): Single<AuthToken>
}