package com.idenfy.idenfy_sample_android.domain.usecases

import com.idenfy.idenfy_sample_android.data.models.AuthToken
import com.idenfy.idenfy_sample_android.data.models.AuthTokenBody
import com.idenfy.idenfy_sample_android.networking.APIService
import com.idenfy.idenfy_sample_android.networking.rx.RxJavaUtils
import io.reactivex.Single

class GetIdenfyAuthTokenUseCase(
    private val apiService: APIService,
    private val rxJavaUtils: RxJavaUtils
) {


    fun execute(authTokenBody: AuthTokenBody): Single<AuthToken> {
        return apiService.getAppToken(authTokenBody).subscribeOn(rxJavaUtils.getSchedulersIO())
    }

}