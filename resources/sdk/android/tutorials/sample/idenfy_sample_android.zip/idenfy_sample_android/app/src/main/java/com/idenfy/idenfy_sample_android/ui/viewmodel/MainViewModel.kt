package com.idenfy.idenfy_sample_android.ui.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.idenfy.idenfy_sample_android.data.models.AuthTokenBody
import com.idenfy.idenfy_sample_android.di.ServiceLocator
import com.idenfy.idenfy_sample_android.domain.usecases.GetIdenfyAuthTokenUseCase
import com.idenfy.idenfy_sample_android.domain.utils.Consts
import com.idenfy.idenfy_sample_android.networking.rx.RxJavaUtils
import com.idenfy.idenfy_sample_android.ui.presentation.IdenfyAuthTokenState
import io.reactivex.disposables.CompositeDisposable

class MainViewModel : ViewModel() {

    private var serviceLocator = ServiceLocator()
    private var getIdenfyAuthTokenUseCase: GetIdenfyAuthTokenUseCase
    private var rxJavaUtils: RxJavaUtils
    private var compositeDisposable = CompositeDisposable()
    private var _idenfyAuthTokenStateLiveData = MutableLiveData<IdenfyAuthTokenState>()
    val idenfyAuthTokenStateLiveData: LiveData<IdenfyAuthTokenState>
        get() = _idenfyAuthTokenStateLiveData

    init {
        rxJavaUtils = serviceLocator.rxJavaUtils
        getIdenfyAuthTokenUseCase =
            GetIdenfyAuthTokenUseCase(serviceLocator.apiService, rxJavaUtils)
        resetAuthTokenState()
    }

    override fun onCleared() {
        compositeDisposable.dispose()
        super.onCleared()
    }

    fun resetAuthTokenState() {
        _idenfyAuthTokenStateLiveData.value = IdenfyAuthTokenState.NotStarted
    }

    fun getIdenfyAuthToken() {
        _idenfyAuthTokenStateLiveData.value = IdenfyAuthTokenState.Loading
        val authTokenBody =
            AuthTokenBody(Consts.clientId)
        val disposable = getIdenfyAuthTokenUseCase.execute(authTokenBody)
            .observeOn(rxJavaUtils.getAndroidSchedulersMainThread())
            .subscribe({ authToken ->
                _idenfyAuthTokenStateLiveData.value = IdenfyAuthTokenState.Success(authToken)

            }, {
                _idenfyAuthTokenStateLiveData.value =
                    IdenfyAuthTokenState.AuthTokenCouldNotBeReceived(it)
            })
        compositeDisposable.add(disposable)
    }

}