package com.idenfy.idenfy_sample_android.networking

import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.idenfy.idenfy_sample_android.BuildConfig
import com.idenfy.idenfy_sample_android.domain.utils.Consts
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object RetrofitFactory {
    private val gson: Gson = GsonBuilder()
        .setLenient()
        .create()

    private val interceptor: HttpLoggingInterceptor =
        HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.BODY)

    private fun makeOkhttpClient(): OkHttpClient {
        val client = OkHttpClient.Builder()
            .connectTimeout(300, TimeUnit.SECONDS)
            .writeTimeout(300, TimeUnit.SECONDS)
            .readTimeout(300, TimeUnit.SECONDS)
        client.addInterceptor(
            BasicAuthInterceptor(
                Consts.apiKey,
                Consts.apiSecret
            )
        )
        client.addInterceptor(interceptor)
        client.retryOnConnectionFailure(true)
            .addNetworkInterceptor { chain ->
                val request = chain.request().newBuilder().addHeader("Connection", "close").build()
                chain.proceed(request)
            }


        return client.build()
    }

    fun makeRetrofitService(): APIService {
        val retrofitBuilder = Retrofit.Builder()
        retrofitBuilder.baseUrl(BuildConfig.BASE_URL)
        retrofitBuilder.addCallAdapterFactory(RxJava2CallAdapterFactory.create())
        retrofitBuilder.client(makeOkhttpClient())
            .addConverterFactory(GsonConverterFactory.create(gson))
        return retrofitBuilder.build().create(APIService::class.java)
    }
}